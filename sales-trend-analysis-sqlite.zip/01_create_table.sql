-- Step 1: Create table for online sales

CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY,
    order_date TEXT NOT NULL,
    product_id INTEGER,
    amount REAL
);
