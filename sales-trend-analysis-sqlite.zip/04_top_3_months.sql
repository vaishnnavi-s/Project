-- Step 4: Get top 3 months by total revenue

SELECT
    strftime('%Y', order_date) AS order_year,
    strftime('%m', order_date) AS order_month,
    SUM(amount) AS total_revenue
FROM orders
GROUP BY order_year, order_month
ORDER BY total_revenue DESC
LIMIT 3;
